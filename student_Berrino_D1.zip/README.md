# IMY-220
By Fabio Berrino
u23526387

This repository is for the first Deliverable of the project for IMY 220.
In this deliverable is the wireframe for the splash, home, profile and playlist pages.
Website name = RecordShare

GitHub:Life220
Link: https://github.com/Life220/IMY-220.git